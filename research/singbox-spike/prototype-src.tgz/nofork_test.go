package spike

import (
	"encoding/binary"
	"io"
	"net"
	"os"
	"testing"
	"time"
)

func only(t *testing.T) []proto {
	ps := protos()
	if f := os.Getenv("SPIKE_PROTO"); f != "" {
		var r []proto
		for _, p := range ps {
			if p.Name == f {
				r = append(r, p)
			}
		}
		return r
	}
	return ps
}

// (a)(b)(c): live revocation, per-user accounting incl. UDP, speed limit.
func TestNoForkRevokeAccountLimit(t *testing.T) {
	e := newEnv(t)
	ps := only(t)
	s := startServer(t, e, ps, []user{alice, bob}, false)
	for _, p := range ps {
		t.Run(p.Name, func(t *testing.T) {
			ka, kb := Key{p.Tag, alice.Name}, Key{p.Tag, bob.Name}
			ca, cb := startClient(t, e, p, alice), startClient(t, e, p, bob)

			// --- (b) accounting, TCP exact ---
			a1, err := ca.dial(e.tcpEcho)
			if err != nil {
				t.Fatal("alice dial:", err)
			}
			defer a1.Close()
			if err := echo(a1, 1, 10*time.Second); err != nil { // warm-up (handshake)
				t.Fatal("alice echo:", err)
			}
			time.Sleep(100 * time.Millisecond)
			c := s.gate.Counter(ka)
			u0, d0 := c.Up.Load(), c.Down.Load()
			if err := echo(a1, 50000, 10*time.Second); err != nil {
				t.Fatal(err)
			}
			time.Sleep(200 * time.Millisecond)
			t.Logf("TCP acct alice: up +%d down +%d (expect 50000/50000)", c.Up.Load()-u0, c.Down.Load()-d0)
			if c.Up.Load()-u0 != 50000 || c.Down.Load()-d0 != 50000 {
				t.Errorf("TCP accounting mismatch")
			}

			// --- (b) accounting, UDP exact ---
			ua, err := ca.udp(e.udpEcho)
			if err != nil {
				t.Fatal("alice udp:", err)
			}
			defer ua.Close()
			if _, err := udpEcho(ua, e.udpEcho, 10, 1, 5*time.Second); err != nil {
				t.Fatal("alice udp warmup:", err)
			}
			time.Sleep(100 * time.Millisecond)
			u0, d0 = c.Up.Load(), c.Down.Load()
			got, err := udpEcho(ua, e.udpEcho, 1000, 20, 10*time.Second)
			time.Sleep(200 * time.Millisecond)
			t.Logf("UDP acct alice: echoed %d, up +%d down +%d (expect 20000/20000) err=%v", got, c.Up.Load()-u0, c.Down.Load()-d0, err)
			if err != nil || c.Up.Load()-u0 != 20000 || c.Down.Load()-d0 != 20000 {
				t.Errorf("UDP accounting mismatch")
			}

			// --- (c) per-user speed limit: 1 MiB/s for alice, bob unlimited ---
			s.gate.SetLimit(alice.Name, 1<<20)
			rate := func(cl *client, n int64) float64 {
				conn, err := cl.dial(e.source)
				if err != nil {
					t.Fatal(err)
				}
				defer conn.Close()
				var h [8]byte
				binary.BigEndian.PutUint64(h[:], uint64(n))
				st := time.Now()
				conn.Write(h[:])
				conn.SetDeadline(time.Now().Add(30 * time.Second))
				m, err := io.Copy(io.Discard, conn)
				if m != n {
					t.Errorf("short read %d/%d %v", m, n, err)
				}
				return float64(n) / time.Since(st).Seconds() / (1 << 20)
			}
			ra := rate(ca, 4<<20)
			rb := rate(cb, 32<<20)
			t.Logf("rate: alice(limited 1MiB/s) %.2f MiB/s, bob(unlimited) %.1f MiB/s", ra, rb)
			if ra > 1.3 || ra < 0.6 {
				t.Errorf("alice rate %.2f not ≈1 MiB/s", ra)
			}
			s.gate.SetLimit(alice.Name, 0)

			// --- (a) live revocation ---
			a2, err := ca.dial(e.tcpEcho) // second stream (same mux/QUIC session where applicable)
			if err != nil {
				t.Fatal(err)
			}
			defer a2.Close()
			if err := echo(a2, 10, 5*time.Second); err != nil {
				t.Fatal(err)
			}
			b1, err := cb.dial(e.tcpEcho)
			if err != nil {
				t.Fatal(err)
			}
			defer b1.Close()
			if err := echo(b1, 10, 5*time.Second); err != nil {
				t.Fatal(err)
			}
			ub, _ := cb.udp(e.udpEcho)
			defer ub.Close()
			if _, err := udpEcho(ub, e.udpEcho, 100, 1, 5*time.Second); err != nil {
				t.Fatal("bob udp:", err)
			}
			liveA := s.gate.Live(ka)
			dialsBefore, acceptsBefore := s.gate.Dials.Load(), e.echoAccepts.Load()
			st := time.Now()
			closed := s.gate.Revoke(ka)
			a1dead, a2dead := dead(a1, 3*time.Second), dead(a2, 3*time.Second)
			_, uerr := udpEcho(ua, e.udpEcho, 100, 1, 2*time.Second)
			t.Logf("revoke alice: closed %d/%d live; a1 cut=%v a2 cut=%v (%.0fms); alice udp after: err=%v", closed, liveA, a1dead, a2dead, float64(time.Since(st).Milliseconds()), uerr)
			if !a1dead || !a2dead || uerr == nil {
				t.Errorf("revocation did not cut alice")
			}
			// new connection of alice is refused before any outbound dial
			n1, nerr := ca.dial(e.tcpEcho)
			newCut := true
			if nerr == nil {
				newCut = echo(n1, 10, 3*time.Second) != nil
				n1.Close()
			}
			nu, _ := ca.udp(e.udpEcho)
			var nuerr error = net.ErrClosed
			if nu != nil {
				_, nuerr = udpEcho(nu, e.udpEcho, 100, 1, 2*time.Second)
				nu.Close()
			}
			t.Logf("alice new TCP refused=%v, new UDP refused=%v; outbound dials during refusal=%d, echo accepts=%d, refused=%d",
				newCut, nuerr != nil, s.gate.Dials.Load()-dialsBefore, e.echoAccepts.Load()-acceptsBefore, s.gate.Refused.Load())
			if !newCut || nuerr == nil || s.gate.Dials.Load() != dialsBefore {
				t.Errorf("new alice traffic not refused at route time")
			}
			// bob unaffected
			if err := echo(b1, 1000, 5*time.Second); err != nil {
				t.Errorf("bob TCP broken by alice revoke: %v", err)
			}
			if _, err := udpEcho(ub, e.udpEcho, 100, 3, 5*time.Second); err != nil {
				t.Errorf("bob UDP broken by alice revoke: %v", err)
			}
			_ = kb
		})
	}
}

// (d): user ADD by InboundManager.Create(same tag) — what happens to the
// other users' existing connections / sessions?
func TestNoForkAddUserByReplace(t *testing.T) {
	e := newEnv(t)
	ps := only(t)
	s := startServer(t, e, ps, []user{alice, bob}, true)
	for _, p := range ps {
		t.Run(p.Name, func(t *testing.T) {
			cb := startClient(t, e, p, bob)
			b1, err := cb.dial(e.tcpEcho)
			if err != nil {
				t.Fatal(err)
			}
			defer b1.Close()
			if err := echo(b1, 10, 10*time.Second); err != nil {
				t.Fatal(err)
			}
			ub, err := cb.udp(e.udpEcho)
			if err != nil {
				t.Fatal(err)
			}
			defer ub.Close()
			if _, err := udpEcho(ub, e.udpEcho, 100, 1, 5*time.Second); err != nil {
				t.Fatal(err)
			}
			st := time.Now()
			if err := s.replaceInbound(t, e, p, []user{alice, bob, carol}); err != nil {
				t.Fatal("replace:", err)
			}
			s.gate.Allow(Key{p.Tag, carol.Name})
			took := time.Since(st)
			time.Sleep(300 * time.Millisecond)
			tcpErr := echo(b1, 1000, 5*time.Second)
			_, udpErr := udpEcho(ub, e.udpEcho, 100, 3, 5*time.Second)
			// a new stream from bob's existing client (reuses mux/QUIC session if any)
			var newErr error
			if b2, err := cb.dial(e.tcpEcho); err != nil {
				newErr = err
			} else {
				newErr = echo(b2, 10, 10*time.Second)
				b2.Close()
			}
			cc := startClient(t, e, p, carol)
			var carolErr error
			if c1, err := cc.dial(e.tcpEcho); err != nil {
				carolErr = err
			} else {
				carolErr = echo(c1, 10, 10*time.Second)
				c1.Close()
			}
			t.Logf("REPLACE %s (%v): bob existing TCP err=%v | bob existing UDP err=%v | bob new stream err=%v | carol err=%v",
				p.Name, took.Round(time.Millisecond), tcpErr, udpErr, newErr, carolErr)
		})
	}
}
