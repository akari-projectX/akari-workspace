// SPIKE: per-user revocation, accounting and rate limiting for an embedded
// UPSTREAM sing-box (no fork), using only public APIs:
//   - adapter.Router.AppendTracker (ConnectionTracker): every routed TCP
//     stream / UDP session, incl. mux sub-streams and QUIC streams, passes
//     here with metadata.User set by the inbound;
//   - a custom outbound type registered in the public outbound registry,
//     which refuses to dial for a revoked user (the tracker cannot fail a
//     route; without this, the router would still dial the destination).
package spikefork

import (
	"context"
	"errors"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"github.com/sagernet/sing-box/adapter"
	"github.com/sagernet/sing-box/adapter/outbound"
	"github.com/sagernet/sing-box/log"
	"github.com/sagernet/sing-box/option"
	"github.com/sagernet/sing-box/protocol/direct"
	tun "github.com/sagernet/sing-tun"
	"github.com/sagernet/sing/common/buf"
	"github.com/sagernet/sing/common/bufio"
	M "github.com/sagernet/sing/common/metadata"
	N "github.com/sagernet/sing/common/network"
	"github.com/sagernet/sing/service"
	"golang.org/x/time/rate"
)

var errRevoked = errors.New("akari: user access revoked")

type Key struct{ Inbound, User string }

type Counter struct{ Up, Down atomic.Int64 }

type Gate struct {
	mu       sync.Mutex
	allowed  map[Key]*adapter.ManagedUser // the ONLY admissible identity per key (pointer, like the xray gate's *MemoryUser)
	live     map[Key]map[*liveConn]struct{}
	counters map[Key]*Counter
	limits   map[string]*rate.Limiter // per user (all inbounds)
	Dials    atomic.Int64             // outbound dials actually attempted
	Refused  atomic.Int64             // refusals (tracker or outbound)
}

type liveConn struct{ close func() error }

func NewGate() *Gate {
	return &Gate{
		allowed:  map[Key]*adapter.ManagedUser{},
		live:     map[Key]map[*liveConn]struct{}{},
		counters: map[Key]*Counter{},
		limits:   map[string]*rate.Limiter{},
	}
}

// Allow installs u as the only admissible identity for k; a different
// previous identity (rotated credential) loses its live streams.
func (g *Gate) Allow(k Key, u *adapter.ManagedUser) int {
	g.mu.Lock()
	prev := g.allowed[k]
	g.allowed[k] = u
	var victims map[*liveConn]struct{}
	if prev != nil && prev != u {
		victims = g.live[k]
		delete(g.live, k)
	}
	g.mu.Unlock()
	for c := range victims {
		_ = c.close()
	}
	return len(victims)
}

// Revoke refuses k at route time from now on and closes every live
// routed stream/session of k. Returns how many were closed.
func (g *Gate) Revoke(k Key) int {
	g.mu.Lock()
	delete(g.allowed, k)
	victims := g.live[k]
	delete(g.live, k)
	g.mu.Unlock()
	for c := range victims {
		_ = c.close()
	}
	return len(victims)
}

func (g *Gate) Live(k Key) int { g.mu.Lock(); defer g.mu.Unlock(); return len(g.live[k]) }

func (g *Gate) Counter(k Key) *Counter {
	g.mu.Lock()
	defer g.mu.Unlock()
	c := g.counters[k]
	if c == nil {
		c = new(Counter)
		g.counters[k] = c
	}
	return c
}

// SetLimit: bytes/s per user, shared by up+down of all its connections.
func (g *Gate) SetLimit(user string, bps int) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if bps <= 0 {
		delete(g.limits, user)
		return
	}
	g.limits[user] = rate.NewLimiter(rate.Limit(bps), 64*1024)
}

func (g *Gate) admitted(ctx context.Context, m adapter.InboundContext) bool {
	u, ok := adapter.ManagedUserFromContext(ctx)
	if !ok || m.User == "" || u.Name != m.User {
		return false // fail closed
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	return g.allowed[Key{m.Inbound, m.User}] == u
}

func (g *Gate) track(ctx context.Context, k Key, closer func() error) (*liveConn, bool) {
	u, _ := adapter.ManagedUserFromContext(ctx)
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.allowed[k] != u || u == nil { // revoked/rotated between admit and track
		return nil, false
	}
	lc := &liveConn{close: closer}
	if g.live[k] == nil {
		g.live[k] = map[*liveConn]struct{}{}
	}
	g.live[k][lc] = struct{}{}
	return lc, true
}

func (g *Gate) untrack(k Key, lc *liveConn) {
	g.mu.Lock()
	delete(g.live[k], lc)
	g.mu.Unlock()
}

func (g *Gate) limiter(user string) *rate.Limiter {
	g.mu.Lock()
	defer g.mu.Unlock()
	return g.limits[user]
}

// ---- adapter.ConnectionTracker ----

func (g *Gate) RoutedConnection(ctx context.Context, conn net.Conn, m adapter.InboundContext, _ adapter.Rule, _ adapter.Outbound) net.Conn {
	k := Key{m.Inbound, m.User}
	if !g.admitted(ctx, m) {
		g.Refused.Add(1)
		conn.Close()
		return conn
	}
	c := g.Counter(k)
	// read from inbound side = uplink, write = downlink (same as upstream v2rayapi stats)
	var wrapped net.Conn = bufio.NewInt64CounterConn(conn, []*atomic.Int64{&c.Up}, []*atomic.Int64{&c.Down})
	tc := &trackedConn{Conn: wrapped, g: g, k: k}
	lc, ok := g.track(ctx, k, conn.Close)
	if !ok {
		g.Refused.Add(1)
		conn.Close()
		return conn
	}
	tc.lc = lc
	return tc
}

func (g *Gate) RoutedPacketConnection(ctx context.Context, conn N.PacketConn, m adapter.InboundContext, _ adapter.Rule, _ adapter.Outbound) N.PacketConn {
	k := Key{m.Inbound, m.User}
	if !g.admitted(ctx, m) {
		g.Refused.Add(1)
		conn.Close()
		return conn
	}
	c := g.Counter(k)
	wrapped := bufio.NewInt64CounterPacketConn(conn, []*atomic.Int64{&c.Up}, nil, []*atomic.Int64{&c.Down}, nil)
	tp := &trackedPacketConn{PacketConn: wrapped, g: g, k: k}
	lc, ok := g.track(ctx, k, conn.Close)
	if !ok {
		g.Refused.Add(1)
		conn.Close()
		return conn
	}
	tp.lc = lc
	return tp
}

func (g *Gate) RoutedFlow(context.Context, adapter.InboundContext, adapter.Rule, adapter.Outbound) tun.FlowTracker {
	return nil // TUN/L3 flows only; not used by proxy inbounds
}

// trackedConn hides the counter conn's fast-path interfaces on purpose
// (the limiter must see every byte); the counter still sees them all.
type trackedConn struct {
	net.Conn
	g    *Gate
	k    Key
	lc   *liveConn
	once sync.Once
}

func (c *trackedConn) wait(n int) {
	if l := c.g.limiter(c.k.User); l != nil {
		for n > 0 {
			chunk := min(n, l.Burst())
			_ = l.WaitN(context.Background(), chunk)
			n -= chunk
		}
	}
}

func (c *trackedConn) Read(p []byte) (int, error) {
	if l := c.g.limiter(c.k.User); l != nil && len(p) > l.Burst() {
		p = p[:l.Burst()]
	}
	n, err := c.Conn.Read(p)
	c.wait(n)
	return n, err
}

func (c *trackedConn) Write(p []byte) (int, error) {
	c.wait(len(p))
	return c.Conn.Write(p)
}

func (c *trackedConn) Close() error {
	c.once.Do(func() { c.g.untrack(c.k, c.lc) })
	return c.Conn.Close()
}

type trackedPacketConn struct {
	N.PacketConn
	g    *Gate
	k    Key
	lc   *liveConn
	once sync.Once
}

func (c *trackedPacketConn) wait(n int) {
	if l := c.g.limiter(c.k.User); l != nil {
		_ = l.WaitN(context.Background(), min(n, l.Burst()))
	}
}

func (c *trackedPacketConn) ReadPacket(b *buf.Buffer) (M.Socksaddr, error) {
	d, err := c.PacketConn.ReadPacket(b)
	if err == nil {
		c.wait(b.Len())
	}
	return d, err
}

func (c *trackedPacketConn) WritePacket(b *buf.Buffer, d M.Socksaddr) error {
	c.wait(b.Len())
	return c.PacketConn.WritePacket(b, d)
}

func (c *trackedPacketConn) Close() error {
	c.once.Do(func() { c.g.untrack(c.k, c.lc) })
	return c.PacketConn.Close()
}

// ---- gate outbound: direct, but refuses revoked users before dialing ----

const GateOutboundType = "akari-gate"

type gateOutbound struct {
	outbound.Adapter
	inner adapter.Outbound
	gate  *Gate
}

func RegisterGateOutbound(reg *outbound.Registry, g *Gate) {
	outbound.Register[option.DirectOutboundOptions](reg, GateOutboundType, func(ctx context.Context, router adapter.Router, logger log.ContextLogger, tag string, options option.DirectOutboundOptions) (adapter.Outbound, error) {
		inner, err := direct.NewOutbound(ctx, router, logger, tag, options)
		if err != nil {
			return nil, err
		}
		_ = service.FromContext[adapter.Router]
		return &gateOutbound{Adapter: outbound.NewAdapter(GateOutboundType, tag, inner.Network(), nil), inner: inner, gate: g}, nil
	})
}

func (o *gateOutbound) check(ctx context.Context) error {
	m := adapter.ContextFrom(ctx)
	if m == nil || !o.gate.admitted(ctx, *m) {
		o.gate.Refused.Add(1)
		return errRevoked
	}
	o.gate.Dials.Add(1)
	return nil
}

func (o *gateOutbound) DialContext(ctx context.Context, network string, dst M.Socksaddr) (net.Conn, error) {
	if err := o.check(ctx); err != nil {
		return nil, err
	}
	return o.inner.DialContext(ctx, network, dst)
}

func (o *gateOutbound) ListenPacket(ctx context.Context, dst M.Socksaddr) (net.PacketConn, error) {
	if err := o.check(ctx); err != nil {
		return nil, err
	}
	return o.inner.ListenPacket(ctx, dst)
}

func (o *gateOutbound) Start(stage adapter.StartStage) error {
	return adapter.LegacyStart(o.inner, stage)
}

func (o *gateOutbound) Close() error {
	if c, ok := o.inner.(interface{ Close() error }); ok {
		return c.Close()
	}
	return nil
}

var _ = time.Second

// Expose the inner conn for headroom calculation, but forbid the copier
// from replacing (bypassing) this wrapper: the limiter and the close
// hook must stay on the data path.
func (c *trackedConn) Upstream() any                 { return c.Conn }
func (c *trackedConn) ReaderReplaceable() bool       { return false }
func (c *trackedConn) WriterReplaceable() bool       { return false }
func (c *trackedPacketConn) Upstream() any           { return c.PacketConn }
func (c *trackedPacketConn) ReaderReplaceable() bool { return false }
func (c *trackedPacketConn) WriterReplaceable() bool { return false }
