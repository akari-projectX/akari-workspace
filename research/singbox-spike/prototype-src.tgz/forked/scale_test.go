package spikefork

import (
	"testing"
	"time"
)

func TestPatchedReplaceScale(t *testing.T) {
	e := newEnv(t)
	us := raceUsers(10000)
	ps := []proto{}
	for _, p := range protos() {
		if p.Type == "vless" || p.Type == "hysteria2" || p.Type == "tuic" {
			ps = append(ps, p)
		}
	}
	s := startServer(t, e, ps, us[:1], false)
	for _, p := range ps {
		var best time.Duration
		for r := 0; r < 5; r++ {
			st := time.Now()
			if err := s.setUsers(t, e, p, us[:10000-r]); err != nil {
				t.Fatal(err)
			}
			if d := time.Since(st); best == 0 || d < best {
				best = d
			}
		}
		t.Logf("%s ReplaceUsers(10k) incl. JSON parse + gate update: best %v", p.Name, best)
	}
}
