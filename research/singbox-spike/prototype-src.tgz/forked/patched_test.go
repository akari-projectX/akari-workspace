package spikefork

import (
	"testing"
	"time"
)

// Patched fork, real sing-box clients: ADD keeps everyone else's
// connections/sessions; REMOVE and ROTATE cut the affected user only.
func TestPatchedAddRemoveRotate(t *testing.T) {
	e := newEnv(t)
	var ps []proto
	for _, p := range protos() {
		switch p.Type {
		case "vless", "hysteria2", "tuic":
			ps = append(ps, p)
		}
	}
	s := startServer(t, e, ps, []user{alice, bob}, false)
	for _, p := range ps {
		t.Run(p.Name, func(t *testing.T) {
			ca, cb := startClient(t, e, p, alice), startClient(t, e, p, bob)
			a1, err := ca.dial(e.tcpEcho)
			if err != nil {
				t.Fatal(err)
			}
			defer a1.Close()
			b1, err := cb.dial(e.tcpEcho)
			if err != nil {
				t.Fatal(err)
			}
			defer b1.Close()
			if echo(a1, 10, 10*time.Second) != nil || echo(b1, 10, 10*time.Second) != nil {
				t.Fatal("warmup")
			}
			ub, err := cb.udp(e.udpEcho)
			if err != nil {
				t.Fatal(err)
			}
			defer ub.Close()
			if _, err := udpEcho(ub, e.udpEcho, 100, 1, 5*time.Second); err != nil {
				t.Fatal(err)
			}

			// ADD carol
			st := time.Now()
			if err := s.setUsers(t, e, p, []user{alice, bob, carol}); err != nil {
				t.Fatal(err)
			}
			took := time.Since(st)
			_, uerr := udpEcho(ub, e.udpEcho, 100, 3, 5*time.Second)
			var b2err error
			if b2, err := cb.dial(e.tcpEcho); err != nil {
				b2err = err
			} else {
				b2err = echo(b2, 10, 5*time.Second)
				b2.Close()
			}
			cc := startClient(t, e, p, carol)
			var cerr error
			if c1, err := cc.dial(e.tcpEcho); err != nil {
				cerr = err
			} else {
				cerr = echo(c1, 10, 10*time.Second)
				c1.Close()
			}
			t.Logf("ADD carol (%v): alice existing=%v bob existing TCP=%v UDP=%v bob new stream=%v carol=%v",
				took.Round(time.Microsecond), echo(a1, 1000, 5*time.Second), echo(b1, 1000, 5*time.Second), uerr, b2err, cerr)
			if echo(b1, 10, 5*time.Second) != nil || uerr != nil || b2err != nil || cerr != nil {
				t.Errorf("ADD disturbed others or carol failed")
			}

			// REMOVE alice
			if err := s.setUsers(t, e, p, []user{bob, carol}); err != nil {
				t.Fatal(err)
			}
			aCut := dead(a1, 3*time.Second)
			aNew := true
			if n, err := ca.dial(e.tcpEcho); err == nil {
				aNew = echo(n, 10, 3*time.Second) != nil
				n.Close()
			}
			t.Logf("REMOVE alice: existing cut=%v new refused=%v; bob still ok=%v", aCut, aNew, echo(b1, 100, 5*time.Second) == nil)
			if !aCut || !aNew {
				t.Errorf("remove did not cut alice")
			}

			// ROTATE bob (same name, new credential)
			bob2 := bob
			bob2.UUID, bob2.Pass = "44444444-4444-4444-4444-444444444444", "bob-rotated-password-0123"
			if err := s.setUsers(t, e, p, []user{bob2, carol}); err != nil {
				t.Fatal(err)
			}
			bCut := dead(b1, 3*time.Second)
			oldNew := true // old client (old credential, possibly still-open mux/QUIC session)
			if n, err := cb.dial(e.tcpEcho); err == nil {
				oldNew = echo(n, 10, 3*time.Second) != nil
				n.Close()
			}
			cb2 := startClient(t, e, p, bob2)
			var newErr error
			if n, err := cb2.dial(e.tcpEcho); err != nil {
				newErr = err
			} else {
				newErr = echo(n, 10, 10*time.Second)
				n.Close()
			}
			t.Logf("ROTATE bob: old existing cut=%v old-cred new stream refused=%v new-cred works=%v", bCut, oldNew, newErr == nil)
			if !bCut || !oldNew || newErr != nil {
				t.Errorf("rotation semantics broken")
			}
		})
	}
}
