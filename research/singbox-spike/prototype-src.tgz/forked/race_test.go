package spikefork

import (
	"context"
	"fmt"
	"math/rand/v2"
	"net"
	"os"
	"strconv"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/sagernet/sing-box/adapter"
	sbtls "github.com/sagernet/sing-box/common/tls"
	"github.com/sagernet/sing-box/log"
	"github.com/sagernet/sing-box/option"
	"github.com/sagernet/sing-quic/hysteria2"
	"github.com/sagernet/sing-vmess/vless"
	"github.com/sagernet/sing/common/logger"
	M "github.com/sagernet/sing/common/metadata"
	N "github.com/sagernet/sing/common/network"
	tun "github.com/sagernet/sing-tun"
)

// checker: destination port encodes which user's credential the client
// used (port = 40000 + i, user name "u<i>"). Any other attribution is a
// misattribution; a nil/mismatched ctx identity is a broken invariant.
type checker struct {
	routed, misattributed, noIdentity atomic.Int64
	mu                                sync.Mutex
	byInbound                         map[string]int
	examples                          []string
}

func (c *checker) check(ctx context.Context, m adapter.InboundContext) {
	c.routed.Add(1)
	c.mu.Lock()
	if c.byInbound == nil {
		c.byInbound = map[string]int{}
	}
	c.byInbound[m.Inbound]++
	c.mu.Unlock()
	u, ok := adapter.ManagedUserFromContext(ctx)
	if !ok || u.Name != m.User {
		c.noIdentity.Add(1)
		return
	}
	want := "u" + strconv.Itoa(int(m.Destination.Port)-40000)
	if m.User != want {
		c.misattributed.Add(1)
		c.mu.Lock()
		if len(c.examples) < 5 {
			c.examples = append(c.examples, fmt.Sprintf("%s: client used %s, attributed to %s", m.Inbound, want, m.User))
		}
		c.mu.Unlock()
	}
}

func (c *checker) RoutedConnection(ctx context.Context, conn net.Conn, m adapter.InboundContext, _ adapter.Rule, _ adapter.Outbound) net.Conn {
	c.check(ctx, m)
	return conn
}
func (c *checker) RoutedPacketConnection(ctx context.Context, conn N.PacketConn, m adapter.InboundContext, _ adapter.Rule, _ adapter.Outbound) N.PacketConn {
	c.check(ctx, m)
	return conn
}
func (c *checker) RoutedFlow(context.Context, adapter.InboundContext, adapter.Rule, adapter.Outbound) tun.FlowTracker {
	return nil
}

func raceUsers(n int) []user {
	var us []user
	for i := 0; i < n; i++ {
		us = append(us, user{Name: "u" + strconv.Itoa(i), UUID: fmt.Sprintf("%08d-0000-4000-8000-000000000000", i), Pass: fmt.Sprintf("race-password-%04d-xxxxxx", i)})
	}
	return us
}

// Concurrent handshakes vs user-table replacement (shuffle + drop) on the
// patched fork. Run with -race.
func TestPatchedRaceHandshakeVsReplace(t *testing.T) {
	e := newEnv(t)
	const nUsers = 8
	us := raceUsers(nUsers)
	dur := 8 * time.Second
	if v := os.Getenv("RACE_SECONDS"); v != "" {
		n, _ := strconv.Atoi(v)
		dur = time.Duration(n) * time.Second
	}
	ps := []proto{
		{Name: "vless-plain", Tag: "vl", Type: "vless", Port: 21101,
			server: func(e *env, us []user, reuse bool) map[string]any {
				return merge(listen(21101, reuse), map[string]any{"type": "vless", "tag": "vl",
					"users": mapUsers(us, func(u user) map[string]any { return map[string]any{"name": u.Name, "uuid": u.UUID} })})
			}},
		{Name: "hysteria2", Tag: "hy2", Type: "hysteria2", Port: 21103, QUIC: true,
			server: func(e *env, us []user, reuse bool) map[string]any {
				return merge(listen(21103, reuse), map[string]any{"type": "hysteria2", "tag": "hy2", "tls": e.inTLS("h3"),
					"users": mapUsers(us, func(u user) map[string]any { return map[string]any{"name": u.Name, "password": u.Pass} })})
			}},
		{Name: "tuic", Tag: "tuic", Type: "tuic", Port: 21104, QUIC: true,
			server: func(e *env, us []user, reuse bool) map[string]any {
				return merge(listen(21104, reuse), map[string]any{"type": "tuic", "tag": "tuic", "tls": e.inTLS("h3"),
					"users": mapUsers(us, func(u user) map[string]any { return map[string]any{"name": u.Name, "uuid": u.UUID, "password": u.Pass} })})
			}},
	}
	s := startServer(t, e, ps[:2], us, false) // vless + hy2 (tuic covered functionally)
	chk := &checker{}
	// checker must see the conn before the gate closes refused ones; order
	// does not matter for attribution (metadata is a value).
	s.box.Router().AppendTracker(chk)

	ctx, cancel := context.WithTimeout(context.Background(), dur)
	defer cancel()
	var wg sync.WaitGroup
	var replaces, hsOK, hsFail atomic.Int64

	// churn: random subset in random order, every ~200µs
	wg.Add(1)
	go func() {
		defer wg.Done()
		for ctx.Err() == nil {
			perm := rand.Perm(nUsers)
			k := 1 + rand.IntN(nUsers)
			var sub []user
			for _, i := range perm[:k] {
				sub = append(sub, us[i])
			}
			for _, p := range ps[:2] {
				if err := s.setUsers(t, e, p, sub); err != nil {
					t.Error(err)
					return
				}
			}
			replaces.Add(1)
			time.Sleep(200 * time.Microsecond)
		}
	}()

	// VLESS clients: fresh TCP + VLESS handshake per iteration
	for w := 0; w < 8; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for ctx.Err() == nil {
				i := rand.IntN(nUsers)
				cl, _ := vless.NewClient(us[i].UUID, "", logger.NOP())
				raw, err := net.Dial("tcp", "127.0.0.1:21101")
				if err != nil {
					hsFail.Add(1)
					continue
				}
				c, err := cl.DialEarlyConn(raw, M.ParseSocksaddrHostPort("127.0.0.1", uint16(40000+i)))
				if err == nil {
					_, err = c.Write([]byte{1})
				}
				if err == nil {
					hsOK.Add(1)
				} else {
					hsFail.Add(1)
				}
				raw.SetReadDeadline(time.Now().Add(50 * time.Millisecond))
				var b [1]byte
				raw.Read(b[:])
				raw.Close()
			}
		}()
	}

	// Hysteria2 clients: fresh QUIC connection (=fresh auth) per iteration
	tlsCfg, err := sbtls.NewClient(context.Background(), log.NewNOPFactory().Logger(), "127.0.0.1", option.OutboundTLSOptions{Enabled: true, ServerName: "rt.test", Insecure: true, ALPN: []string{"h3"}})
	if err != nil {
		t.Fatal(err)
	}
	for w := 0; w < 4; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for ctx.Err() == nil {
				i := rand.IntN(nUsers)
				cl, err := hysteria2.NewClient(hysteria2.ClientOptions{
					Context: context.Background(), Dialer: N.SystemDialer, Logger: logger.NOP(),
					ServerAddress: M.ParseSocksaddrHostPort("127.0.0.1", 21103),
					Password:      us[i].Pass, TLSConfig: tlsCfg,
				})
				if err != nil {
					t.Error(err)
					return
				}
				dctx, dcancel := context.WithTimeout(context.Background(), 2*time.Second)
				for j := 0; j < 3; j++ { // several streams per session, interleaved with churn
					c, err := cl.DialConn(dctx, M.ParseSocksaddrHostPort("127.0.0.1", uint16(40000+i)))
					if err == nil {
						_, err = c.Write([]byte{1})
						c.Close()
					}
					if err == nil {
						hsOK.Add(1)
					} else {
						hsFail.Add(1)
						break
					}
				}
				dcancel()
				cl.CloseWithError(nil)
			}
		}()
	}
	wg.Wait()
	// let in-flight routes reach the checker
	time.Sleep(500 * time.Millisecond)
	t.Logf("replaces=%d client handshakes ok=%d failed=%d | routed=%d %v misattributed=%d noIdentity=%d | gate refused=%d dials=%d",
		replaces.Load(), hsOK.Load(), hsFail.Load(), chk.routed.Load(), chk.byInbound, chk.misattributed.Load(), chk.noIdentity.Load(), s.gate.Refused.Load(), s.gate.Dials.Load())
	if chk.misattributed.Load() != 0 || chk.noIdentity.Load() != 0 {
		t.Errorf("identity broken: %v", chk.examples)
	}
	if chk.routed.Load() == 0 {
		t.Errorf("nothing routed")
	}
}
