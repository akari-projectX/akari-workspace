package spike

import (
	"bytes"
	"context"
	"encoding/base64"
	"fmt"
	"math/rand/v2"
	"net"
	"os"
	"strconv"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/sagernet/sing-box/adapter"
	"github.com/sagernet/sing-shadowsocks/shadowaead_2022"
	M "github.com/sagernet/sing/common/metadata"
	N "github.com/sagernet/sing/common/network"
	tun "github.com/sagernet/sing-tun"
)

// NEGATIVE CONTROL on UPSTREAM v1.14.2: the only upstream user-update hook
// (adapter.ManagedSSMServer.UpdateUsers on shadowsocks MultiInbound, used
// by the SSM API service) carries identity as a positional index. Same
// method as the fork race test: port 40000+i encodes the credential used.
type attrChecker struct {
	routed, mis atomic.Int64
	mu          sync.Mutex
	ex          []string
}

func (c *attrChecker) check(m adapter.InboundContext) {
	c.routed.Add(1)
	want := "u" + strconv.Itoa(int(m.Destination.Port)-40000)
	if m.User != want {
		c.mis.Add(1)
		c.mu.Lock()
		if len(c.ex) < 5 {
			c.ex = append(c.ex, fmt.Sprintf("credential of %s attributed to %q", want, m.User))
		}
		c.mu.Unlock()
	}
}
func (c *attrChecker) RoutedConnection(_ context.Context, conn net.Conn, m adapter.InboundContext, _ adapter.Rule, _ adapter.Outbound) net.Conn {
	c.check(m)
	return conn
}
func (c *attrChecker) RoutedPacketConnection(_ context.Context, conn N.PacketConn, m adapter.InboundContext, _ adapter.Rule, _ adapter.Outbound) N.PacketConn {
	c.check(m)
	return conn
}
func (c *attrChecker) RoutedFlow(context.Context, adapter.InboundContext, adapter.Rule, adapter.Outbound) tun.FlowTracker {
	return nil
}

func TestUpstreamSSMUpdateUsersRace(t *testing.T) {
	e := newEnv(t)
	const n = 8
	var us []user
	for i := 0; i < n; i++ {
		us = append(us, user{Name: "u" + strconv.Itoa(i), SSKey: base64.StdEncoding.EncodeToString(bytes.Repeat([]byte{byte(i + 1)}, 16))})
	}
	p := proto{Name: "ss2022", Tag: "ss", Type: "shadowsocks", Port: 21106,
		server: func(e *env, us []user, reuse bool) map[string]any {
			return merge(listen(21106, reuse), map[string]any{"type": "shadowsocks", "tag": "ss", "method": "2022-blake3-aes-128-gcm", "password": ssPSK,
				"users": mapUsers(us, func(u user) map[string]any { return map[string]any{"name": u.Name, "password": u.SSKey} })})
		}}
	s := startServer(t, e, []proto{p}, us, false)
	for _, u := range us {
		s.gate.Allow(Key{"ss", u.Name})
	}
	chk := &attrChecker{}
	s.box.Router().AppendTracker(chk)
	in, _ := s.box.Inbound().Get("ss")
	ssm := in.(adapter.ManagedSSMServer)

	dur := 8 * time.Second
	if v := os.Getenv("RACE_SECONDS"); v != "" {
		x, _ := strconv.Atoi(v)
		dur = time.Duration(x) * time.Second
	}
	ctx, cancel := context.WithTimeout(context.Background(), dur)
	defer cancel()
	var wg sync.WaitGroup
	var replaces atomic.Int64
	wg.Add(1)
	go func() {
		defer wg.Done()
		for ctx.Err() == nil {
			perm := rand.Perm(n)
			k := 1 + rand.IntN(n)
			var names, keys []string
			for _, i := range perm[:k] {
				names, keys = append(names, us[i].Name), append(keys, us[i].SSKey)
			}
			if err := ssm.UpdateUsers(names, keys); err != nil {
				t.Error(err)
				return
			}
			replaces.Add(1)
			time.Sleep(200 * time.Microsecond)
		}
	}()
	for w := 0; w < 8; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for ctx.Err() == nil {
				i := rand.IntN(n)
				method, err := shadowaead_2022.NewWithPassword("2022-blake3-aes-128-gcm", ssPSK+":"+us[i].SSKey, nil)
				if err != nil {
					t.Error(err)
					return
				}
				raw, err := net.Dial("tcp", "127.0.0.1:21106")
				if err != nil {
					continue
				}
				c := method.DialEarlyConn(raw, M.ParseSocksaddrHostPort("127.0.0.1", uint16(40000+i)))
				c.Write([]byte{1})
				raw.SetReadDeadline(time.Now().Add(50 * time.Millisecond))
				var b [1]byte
				raw.Read(b[:])
				raw.Close()
			}
		}()
	}
	wg.Wait()
	time.Sleep(500 * time.Millisecond)
	t.Logf("UPSTREAM SSM UpdateUsers: replaces=%d routed=%d misattributed=%d examples=%v", replaces.Load(), chk.routed.Load(), chk.mis.Load(), chk.ex)
}
