package main

import (
	"crypto/tls"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"os"
	"strconv"
	"sync/atomic"
	"time"
)

func socks(port int, dst string) (net.Conn, error) {
	c, err := net.DialTimeout("tcp", fmt.Sprintf("127.0.0.1:%d", port), 5*time.Second)
	if err != nil {
		return nil, err
	}
	c.SetDeadline(time.Now().Add(15 * time.Second))
	c.Write([]byte{5, 1, 0})
	b := make([]byte, 10)
	if _, err := io.ReadFull(c, b[:2]); err != nil {
		return nil, err
	}
	h, p, _ := net.SplitHostPort(dst)
	ip := net.ParseIP(h).To4()
	pn, _ := strconv.Atoi(p)
	req := []byte{5, 1, 0, 1}
	req = append(req, ip...)
	req = binary.BigEndian.AppendUint16(req, uint16(pn))
	c.Write(req)
	if _, err := io.ReadFull(c, b[:10]); err != nil {
		return nil, err
	}
	if b[1] != 0 {
		return nil, fmt.Errorf("socks rep %d", b[1])
	}
	c.SetDeadline(time.Time{})
	return c, nil
}

func main() {
	switch os.Args[1] {
	case "targets":
		cert, err := tls.LoadX509KeyPair(os.Args[2], os.Args[3])
		if err != nil {
			panic(err)
		}
		el, _ := net.Listen("tcp", "127.0.0.1:22100")
		go func() {
			for {
				c, err := el.Accept()
				if err != nil {
					return
				}
				go func() { io.Copy(c, c); c.Close() }()
			}
		}()
		tl, _ := tls.Listen("tcp", "127.0.0.1:22101", &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13})
		go func() {
			for {
				c, err := tl.Accept()
				if err != nil {
					return
				}
				go func() { io.Copy(io.Discard, c); c.Close() }()
			}
		}()
		fmt.Println("targets up")
		select {}
	case "load":
		n, _ := strconv.Atoi(os.Args[2])
		base, _ := strconv.Atoi(os.Args[3])
		var ok, fail atomic.Int64
		for i := 0; i < n; i++ {
			go func(i int) {
				c, err := socks(base+i, "127.0.0.1:22100")
				if err != nil {
					fail.Add(1)
					fmt.Fprintln(os.Stderr, "conn", i, err)
					return
				}
				buf := make([]byte, 1024)
				in := make([]byte, 1024)
				first := true
				for {
					c.SetDeadline(time.Now().Add(10 * time.Second))
					if _, err := c.Write(buf); err != nil {
						fail.Add(1)
						return
					}
					if _, err := io.ReadFull(c, in); err != nil {
						fail.Add(1)
						fmt.Fprintln(os.Stderr, "conn", i, err)
						return
					}
					if first {
						ok.Add(1)
						first = false
					}
					time.Sleep(time.Second)
				}
			}(i)
		}
		for {
			time.Sleep(2 * time.Second)
			fmt.Printf("active=%d failed=%d\n", ok.Load(), fail.Load())
		}
	}
}
