import json, base64, sys
N=int(sys.argv[1]) if len(sys.argv)>1 else 100
rk=dict(l.split(": ") for l in open("reality.txt").read().strip().split("\n"))
priv,pub=rk["PrivateKey"],rk["PublicKey"]
uid=lambda i:"%08x-0000-4000-8000-%012x"%(i,i)
pw=lambda i:"pw-%06d-abcdefghijkl"%i
psk=lambda i:base64.b64encode(bytes([i%256,(i>>8)%256]+[7]*14)).decode()
spsk=base64.b64encode(bytes([9]*16)).decode()
users=range(N)
import os
cert,key=os.path.abspath('cert.pem'),os.path.abspath('key.pem')
# xray server
x={"log":{"loglevel":"error"},"inbounds":[
 {"tag":"vless","listen":"127.0.0.1","port":22001,"protocol":"vless","settings":{"clients":[{"id":uid(i),"email":"u%d"%i,"flow":"xtls-rprx-vision"} for i in users],"decryption":"none"},
  "streamSettings":{"network":"tcp","security":"reality","realitySettings":{"dest":"127.0.0.1:22101","serverNames":["rt.test"],"privateKey":priv,"shortIds":["0123456789abcdef"]}}},
 {"tag":"hy2","listen":"127.0.0.1","port":22003,"protocol":"hysteria","settings":{"version":2,"clients":[{"auth":pw(i),"email":"u%d"%i} for i in users]},
  "streamSettings":{"network":"hysteria","security":"tls","tlsSettings":{"alpn":["h3"],"certificates":[{"certificateFile":cert,"keyFile":key}]},"hysteriaSettings":{"version":2}}},
 {"tag":"ss","listen":"127.0.0.1","port":22006,"protocol":"shadowsocks","settings":{"method":"2022-blake3-aes-128-gcm","password":spsk,"clients":[{"password":psk(i),"email":"u%d"%i} for i in users],"network":"tcp,udp"}}],
 "outbounds":[{"protocol":"freedom","tag":"direct"}],
 "policy":{"levels":{"0":{"statsUserUplink":True,"statsUserDownlink":True}}},"stats":{}}
json.dump(x,open("xray-server.json","w"),indent=1)
# sing-box server
sb={"log":{"level":"error"},"inbounds":[
 {"type":"vless","tag":"vless","listen":"127.0.0.1","listen_port":22011,"users":[{"name":"u%d"%i,"uuid":uid(i),"flow":"xtls-rprx-vision"} for i in users],
  "tls":{"enabled":True,"server_name":"rt.test","reality":{"enabled":True,"handshake":{"server":"127.0.0.1","server_port":22101},"private_key":priv,"short_id":["0123456789abcdef"]}}},
 {"type":"hysteria2","tag":"hy2","listen":"127.0.0.1","listen_port":22013,"users":[{"name":"u%d"%i,"password":pw(i)} for i in users],"tls":{"enabled":True,"alpn":["h3"],"certificate_path":cert,"key_path":key}},
 {"type":"shadowsocks","tag":"ss","listen":"127.0.0.1","listen_port":22016,"method":"2022-blake3-aes-128-gcm","password":spsk,"users":[{"name":"u%d"%i,"password":psk(i)} for i in users]}],
 "outbounds":[{"type":"akari-gate","tag":"gate"}],"route":{"final":"gate"}}
json.dump(sb,open("sb-server.json","w"),indent=1)
def client(vp,hp,sp,base):
  ins,outs,rules=[],[],[]
  for i in users:
    ins.append({"type":"socks","tag":"in%d"%i,"listen":"127.0.0.1","listen_port":base+i})
    k=i%3
    if k==0: o={"type":"vless","server":"127.0.0.1","server_port":vp,"uuid":uid(i),"flow":"xtls-rprx-vision","tls":{"enabled":True,"server_name":"rt.test","utls":{"enabled":True,"fingerprint":"chrome"},"reality":{"enabled":True,"public_key":pub,"short_id":"0123456789abcdef"}}}
    elif k==1: o={"type":"hysteria2","server":"127.0.0.1","server_port":hp,"password":pw(i),"tls":{"enabled":True,"server_name":"rt.test","insecure":True,"alpn":["h3"]}}
    else: o={"type":"shadowsocks","server":"127.0.0.1","server_port":sp,"method":"2022-blake3-aes-128-gcm","password":spsk+":"+psk(i)}
    o["tag"]="out%d"%i; outs.append(o); rules.append({"inbound":["in%d"%i],"outbound":"out%d"%i})
  return {"log":{"level":"error"},"inbounds":ins,"outbounds":outs,"route":{"rules":rules}}
json.dump(client(22001,22003,22006,30000),open("client-xray.json","w"))
json.dump(client(22011,22013,22016,31000),open("client-sb.json","w"))
