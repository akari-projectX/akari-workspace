// Kernel-only xray process with the same blank imports as akari-agent's
// core.go/protocols.go (xray-core v1.260327.0), for RSS comparison.
package main

import (
	"fmt"
	"os"
	"os/signal"
	"runtime"
	"runtime/debug"
	"strings"
	"syscall"

	_ "github.com/xtls/xray-core/app/dispatcher"
	_ "github.com/xtls/xray-core/app/dns"
	_ "github.com/xtls/xray-core/app/log"
	_ "github.com/xtls/xray-core/app/policy"
	_ "github.com/xtls/xray-core/app/proxyman/inbound"
	_ "github.com/xtls/xray-core/app/proxyman/outbound"
	_ "github.com/xtls/xray-core/app/router"
	_ "github.com/xtls/xray-core/app/stats"
	"github.com/xtls/xray-core/core"
	confserial "github.com/xtls/xray-core/infra/conf/serial"
	_ "github.com/xtls/xray-core/proxy/freedom"
	_ "github.com/xtls/xray-core/proxy/hysteria"
	_ "github.com/xtls/xray-core/proxy/shadowsocks_2022"
	_ "github.com/xtls/xray-core/proxy/trojan"
	_ "github.com/xtls/xray-core/proxy/vless/inbound"
	_ "github.com/xtls/xray-core/proxy/vmess/inbound"
	_ "github.com/xtls/xray-core/transport/internet"
	_ "github.com/xtls/xray-core/transport/internet/grpc"
	_ "github.com/xtls/xray-core/transport/internet/hysteria"
	_ "github.com/xtls/xray-core/transport/internet/reality"
	_ "github.com/xtls/xray-core/transport/internet/splithttp"
	_ "github.com/xtls/xray-core/transport/internet/tcp"
	_ "github.com/xtls/xray-core/transport/internet/tls"
	_ "github.com/xtls/xray-core/transport/internet/websocket"
)

func main() {
	f, err := os.Open(os.Args[1])
	if err != nil {
		panic(err)
	}
	jc, err := confserial.DecodeJSONConfig(f)
	if err != nil {
		panic(err)
	}
	pb, err := jc.Build()
	if err != nil {
		panic(err)
	}
	inst, err := core.New(pb)
	if err != nil {
		panic(err)
	}
	if err := inst.Start(); err != nil {
		panic(err)
	}
	fmt.Println("started")
	ch := make(chan os.Signal, 1)
	signal.Notify(ch, syscall.SIGUSR1, syscall.SIGTERM)
	for s := range ch {
		if s == syscall.SIGTERM {
			return
		}
		var m runtime.MemStats
		runtime.ReadMemStats(&m)
		fmt.Printf("heapinuse=%d sys=%d goroutines=%d\n", m.HeapInuse, m.Sys, runtime.NumGoroutine())
		_ = debug.SetGCPercent
		_ = strings.TrimSpace
	}
}
