#!/bin/bash
# usage: measure.sh <label> <server-cmd...>   (env CLIENT=client-*.json BASE=port)
cd "$(dirname "$0")"
rss() { awk '/VmRSS/{print $2}' /proc/$1/status; }
label=$1; shift
"$@" > out/$label.server.log 2>&1 &
sp=$!
sleep 4
idle=$(rss $sp)
if [ -n "$CLIENT" ]; then
  ../bin/sing-box run -c $CLIENT > out/$label.client.log 2>&1 &
  cp=$!
  sleep 3
  ./out/driver load 100 $BASE > out/$label.load.log 2> out/$label.load.err &
  lp=$!
  sleep 25
  loaded=$(rss $sp)
  act=$(tail -1 out/$label.load.log)
  kill $lp $cp 2>/dev/null; wait $lp $cp 2>/dev/null
fi
kill -USR1 $sp; sleep 0.5
kill $sp; wait $sp 2>/dev/null
echo "$label idle_rss_kb=$idle loaded_rss_kb=${loaded:-na} [$act] $(grep heapinuse out/$label.server.log | tail -1)"
