// Kernel-only upstream sing-box process (include registry, with_quic,
// with_utls) + the spike gate (tracker + gate outbound), for RSS/size.
package main

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"runtime"
	"syscall"

	box "github.com/sagernet/sing-box"
	"github.com/sagernet/sing-box/include"
	"github.com/sagernet/sing-box/option"
	sjson "github.com/sagernet/sing/common/json"

	"spike"
)

func main() {
	raw, err := os.ReadFile(os.Args[1])
	if err != nil {
		panic(err)
	}
	g := spike.NewGate()
	outReg := include.OutboundRegistry()
	spike.RegisterGateOutbound(outReg, g)
	ctx := box.Context(context.Background(), include.InboundRegistry(), outReg, include.EndpointRegistry(),
		include.DNSTransportRegistry(), include.ServiceRegistry(), include.CertificateProviderRegistry())
	opts, err := sjson.UnmarshalExtendedContext[option.Options](ctx, raw)
	if err != nil {
		panic(err)
	}
	b, err := box.New(box.Options{Context: ctx, Options: opts})
	if err != nil {
		panic(err)
	}
	b.Router().AppendTracker(g)
	for _, ib := range opts.Inbounds {
		for i := 0; i < 1000; i++ {
			g.Allow(spike.Key{Inbound: ib.Tag, User: fmt.Sprintf("u%d", i)})
		}
	}
	if err := b.Start(); err != nil {
		panic(err)
	}
	fmt.Println("started")
	ch := make(chan os.Signal, 1)
	signal.Notify(ch, syscall.SIGUSR1, syscall.SIGTERM)
	for s := range ch {
		if s == syscall.SIGTERM {
			b.Close()
			return
		}
		var m runtime.MemStats
		runtime.ReadMemStats(&m)
		fmt.Printf("heapinuse=%d sys=%d goroutines=%d\n", m.HeapInuse, m.Sys, runtime.NumGoroutine())
	}
}
