// Kernel-only upstream sing-box process (include registry, with_quic,
// with_utls) + the spike gate (tracker + gate outbound), for RSS/size.
package main

import (
	"context"
	"fmt"
	"os"
	"os/signal"
	"runtime"
	"syscall"

	box "github.com/sagernet/sing-box"
	"github.com/sagernet/sing-box/adapter/certificate"
	"github.com/sagernet/sing-box/adapter/endpoint"
	"github.com/sagernet/sing-box/adapter/inbound"
	"github.com/sagernet/sing-box/adapter/outbound"
	"github.com/sagernet/sing-box/adapter/service"
	"github.com/sagernet/sing-box/dns"
	"github.com/sagernet/sing-box/dns/transport/local"
	"github.com/sagernet/sing-box/protocol/anytls"
	"github.com/sagernet/sing-box/protocol/direct"
	"github.com/sagernet/sing-box/protocol/hysteria2"
	"github.com/sagernet/sing-box/protocol/shadowsocks"
	"github.com/sagernet/sing-box/protocol/trojan"
	"github.com/sagernet/sing-box/protocol/tuic"
	"github.com/sagernet/sing-box/protocol/vless"
	"github.com/sagernet/sing-box/protocol/vmess"
	_ "github.com/sagernet/sing-box/transport/v2raygrpclite"
	_ "github.com/sagernet/sing-box/transport/v2raywebsocket"
	_ "github.com/sagernet/sing-box/transport/v2rayhttp"
	"github.com/sagernet/sing-box/option"
	sjson "github.com/sagernet/sing/common/json"

	"spike"
)

func main() {
	raw, err := os.ReadFile(os.Args[1])
	if err != nil {
		panic(err)
	}
	g := spike.NewGate()
	// Slim: only the protocols the panel templates use.
	inReg := inbound.NewRegistry()
	for _, r := range []func(*inbound.Registry){vless.RegisterInbound, vmess.RegisterInbound, trojan.RegisterInbound, shadowsocks.RegisterInbound, hysteria2.RegisterInbound, tuic.RegisterInbound, anytls.RegisterInbound} {
		r(inReg)
	}
	outReg := outbound.NewRegistry()
	direct.RegisterOutbound(outReg)
	spike.RegisterGateOutbound(outReg, g)
	dnsReg := dns.NewTransportRegistry()
	local.RegisterTransport(dnsReg)
	ctx := box.Context(context.Background(), inReg, outReg, endpoint.NewRegistry(), dnsReg, service.NewRegistry(), certificate.NewRegistry())
	opts, err := sjson.UnmarshalExtendedContext[option.Options](ctx, raw)
	if err != nil {
		panic(err)
	}
	b, err := box.New(box.Options{Context: ctx, Options: opts})
	if err != nil {
		panic(err)
	}
	b.Router().AppendTracker(g)
	for _, ib := range opts.Inbounds {
		for i := 0; i < 1000; i++ {
			g.Allow(spike.Key{Inbound: ib.Tag, User: fmt.Sprintf("u%d", i)})
		}
	}
	if err := b.Start(); err != nil {
		panic(err)
	}
	fmt.Println("started")
	ch := make(chan os.Signal, 1)
	signal.Notify(ch, syscall.SIGUSR1, syscall.SIGTERM)
	for s := range ch {
		if s == syscall.SIGTERM {
			b.Close()
			return
		}
		var m runtime.MemStats
		runtime.ReadMemStats(&m)
		fmt.Printf("heapinuse=%d sys=%d goroutines=%d\n", m.HeapInuse, m.Sys, runtime.NumGoroutine())
	}
}
