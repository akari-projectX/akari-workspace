package spike

import (
	"testing"
	"time"
)

// How long until an existing QUIC client (bob) can pass traffic again after
// InboundManager.Create(same tag) replaced the inbound?
func TestNoForkQUICRecovery(t *testing.T) {
	e := newEnv(t)
	var ps []proto
	for _, p := range protos() {
		if p.QUIC {
			ps = append(ps, p)
		}
	}
	s := startServer(t, e, ps, []user{alice, bob}, true)
	for _, p := range ps {
		t.Run(p.Name, func(t *testing.T) {
			cb := startClient(t, e, p, bob)
			b1, err := cb.dial(e.tcpEcho)
			if err != nil {
				t.Fatal(err)
			}
			if err := echo(b1, 10, 10*time.Second); err != nil {
				t.Fatal(err)
			}
			if err := s.replaceInbound(t, e, p, []user{alice, bob, carol}); err != nil {
				t.Fatal(err)
			}
			st := time.Now()
			for time.Since(st) < 120*time.Second {
				c, err := cb.dial(e.tcpEcho)
				if err == nil {
					err = echo(c, 10, 2*time.Second)
					c.Close()
				}
				if err == nil {
					t.Logf("%s: bob's client usable again after %v", p.Name, time.Since(st).Round(100*time.Millisecond))
					return
				}
			}
			t.Errorf("%s: not recovered in 120s", p.Name)
		})
	}
}
