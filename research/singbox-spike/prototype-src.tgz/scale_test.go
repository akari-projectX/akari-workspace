package spike

import (
	"fmt"
	"testing"
	"time"
)

func TestNoForkReplaceScale(t *testing.T) {
	e := newEnv(t)
	var us []user
	for i := 0; i < 10000; i++ {
		us = append(us, user{Name: fmt.Sprintf("u%d", i), UUID: fmt.Sprintf("%08d-0000-4000-8000-000000000000", i), Pass: fmt.Sprintf("race-password-%04d-xxxxxx", i), SSKey: alice.SSKey})
	}
	ps := protos()
	s := startServer(t, e, ps, us[:1], true)
	for _, p := range ps {
		if p.Type == "shadowsocks" {
			continue // duplicate keys rejected; not needed for timing
		}
		var best time.Duration
		for r := 0; r < 3; r++ {
			st := time.Now()
			if err := s.replaceInbound(t, e, p, us[:10000-r]); err != nil {
				t.Fatal(err)
			}
			if d := time.Since(st); best == 0 || d < best {
				best = d
			}
		}
		t.Logf("%s InboundManager.Create replace (10k users) incl. JSON parse: best %v", p.Name, best)
	}
}
