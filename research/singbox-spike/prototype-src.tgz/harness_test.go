package spike

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"io"
	"math/big"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	box "github.com/sagernet/sing-box"
	"github.com/sagernet/sing-box/include"
	"github.com/sagernet/sing-box/option"
	sjson "github.com/sagernet/sing/common/json"
	M "github.com/sagernet/sing/common/metadata"
	N "github.com/sagernet/sing/common/network"
	"github.com/sagernet/sing/protocol/socks"
)

var singboxBin = func() string { p, _ := filepath.Abs("bin/sing-box"); return p }()

type env struct {
	certPEM, keyPEM string
	realityPriv     string
	realityPub      string
	realityDest     int
	tcpEcho         int
	udpEcho         int
	source          int // writes N bytes (first 8 bytes of request = N)
	echoAccepts     atomic.Int64
}

func pemLines(s string) []string { return strings.Split(strings.TrimSpace(s), "\n") }

func newEnv(t testing.TB) *env {
	k, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	tpl := &x509.Certificate{SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "rt.test"}, DNSNames: []string{"rt.test"},
		NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(24 * time.Hour)}
	der, _ := x509.CreateCertificate(rand.Reader, tpl, tpl, &k.PublicKey, k)
	kd, _ := x509.MarshalECPrivateKey(k)
	e := &env{
		certPEM: string(pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})),
		keyPEM:  string(pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: kd})),
	}
	out, err := exec.Command(singboxBin, "generate", "reality-keypair").Output()
	if err != nil {
		t.Fatal(err)
	}
	for _, l := range strings.Split(string(out), "\n") {
		if v, ok := strings.CutPrefix(l, "PrivateKey: "); ok {
			e.realityPriv = v
		}
		if v, ok := strings.CutPrefix(l, "PublicKey: "); ok {
			e.realityPub = v
		}
	}
	cert, _ := tls.X509KeyPair([]byte(e.certPEM), []byte(e.keyPEM))
	// REALITY target (TLS 1.3)
	tl, _ := tls.Listen("tcp", "127.0.0.1:0", &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13})
	go func() {
		for {
			c, err := tl.Accept()
			if err != nil {
				return
			}
			go func() { io.Copy(io.Discard, c); c.Close() }()
		}
	}()
	e.realityDest = tl.Addr().(*net.TCPAddr).Port
	el, _ := net.Listen("tcp", "127.0.0.1:0")
	go func() {
		for {
			c, err := el.Accept()
			if err != nil {
				return
			}
			e.echoAccepts.Add(1)
			go func() { io.Copy(c, c); c.Close() }()
		}
	}()
	e.tcpEcho = el.Addr().(*net.TCPAddr).Port
	sl, _ := net.Listen("tcp", "127.0.0.1:0")
	go func() {
		for {
			c, err := sl.Accept()
			if err != nil {
				return
			}
			go func() {
				defer c.Close()
				var hdr [8]byte
				if _, err := io.ReadFull(c, hdr[:]); err != nil {
					return
				}
				n := int64(0)
				for _, b := range hdr {
					n = n<<8 | int64(b)
				}
				io.CopyN(c, zeroReader{}, n)
			}()
		}
	}()
	e.source = sl.Addr().(*net.TCPAddr).Port
	uc, _ := net.ListenPacket("udp", "127.0.0.1:0")
	go func() {
		b := make([]byte, 65536)
		for {
			n, a, err := uc.ReadFrom(b)
			if err != nil {
				return
			}
			uc.WriteTo(b[:n], a)
		}
	}()
	e.udpEcho = uc.LocalAddr().(*net.UDPAddr).Port
	return e
}

type zeroReader struct{}

func (zeroReader) Read(p []byte) (int, error) { clear(p); return len(p), nil }

// ---- protocols ----

type user struct{ Name, UUID, Pass, SSKey string }

var (
	alice = user{"alice", "11111111-1111-1111-1111-111111111111", "alice-password-0123456789", b64(16, 1)}
	bob   = user{"bob", "22222222-2222-2222-2222-222222222222", "bob-password-0123456789ab", b64(16, 2)}
	carol = user{"carol", "33333333-3333-3333-3333-333333333333", "carol-password-0123456789", b64(16, 3)}
	ssPSK = b64(16, 9)
)

func b64(n int, fill byte) string { return base64.StdEncoding.EncodeToString(bytes.Repeat([]byte{fill}, n)) }

type proto struct {
	Name, Tag, Type string
	Port            int
	QUIC            bool
	server          func(e *env, users []user, reuse bool) map[string]any
	client          func(e *env, u user, port int) map[string]any
}

func (e *env) inTLS(alpn ...string) map[string]any {
	m := map[string]any{"enabled": true, "server_name": "rt.test", "certificate": pemLines(e.certPEM), "key": pemLines(e.keyPEM)}
	if len(alpn) > 0 {
		m["alpn"] = alpn
	}
	return m
}

func outTLS(alpn ...string) map[string]any {
	m := map[string]any{"enabled": true, "server_name": "rt.test", "insecure": true}
	if len(alpn) > 0 {
		m["alpn"] = alpn
	}
	return m
}

func listen(port int, reuse bool) map[string]any {
	return map[string]any{"listen": "127.0.0.1", "listen_port": port, "reuse_addr": reuse}
}

func merge(ms ...map[string]any) map[string]any {
	r := map[string]any{}
	for _, m := range ms {
		for k, v := range m {
			r[k] = v
		}
	}
	return r
}

func mapUsers(us []user, f func(u user) map[string]any) []map[string]any {
	var r []map[string]any
	for _, u := range us {
		r = append(r, f(u))
	}
	return r
}

func protos() []proto {
	return []proto{
		{Name: "vless-reality-vision", Tag: "vlv", Type: "vless", Port: 21001,
			server: func(e *env, us []user, reuse bool) map[string]any {
				return merge(listen(21001, reuse), map[string]any{"type": "vless", "tag": "vlv",
					"users": mapUsers(us, func(u user) map[string]any { return map[string]any{"name": u.Name, "uuid": u.UUID, "flow": "xtls-rprx-vision"} }),
					"tls": map[string]any{"enabled": true, "server_name": "rt.test", "reality": map[string]any{"enabled": true,
						"handshake": map[string]any{"server": "127.0.0.1", "server_port": e.realityDest}, "private_key": e.realityPriv, "short_id": []string{"0123456789abcdef"}}}})
			},
			client: func(e *env, u user, port int) map[string]any {
				return map[string]any{"type": "vless", "tag": "out", "server": "127.0.0.1", "server_port": port, "uuid": u.UUID, "flow": "xtls-rprx-vision",
					"packet_encoding": "xudp",
					"tls": map[string]any{"enabled": true, "server_name": "rt.test", "utls": map[string]any{"enabled": true, "fingerprint": "chrome"},
						"reality": map[string]any{"enabled": true, "public_key": e.realityPub, "short_id": "0123456789abcdef"}}}
			}},
		{Name: "vless-reality-mux", Tag: "vlm", Type: "vless", Port: 21002,
			server: func(e *env, us []user, reuse bool) map[string]any {
				return merge(listen(21002, reuse), map[string]any{"type": "vless", "tag": "vlm", "multiplex": map[string]any{"enabled": true},
					"users": mapUsers(us, func(u user) map[string]any { return map[string]any{"name": u.Name, "uuid": u.UUID} }),
					"tls": map[string]any{"enabled": true, "server_name": "rt.test", "reality": map[string]any{"enabled": true,
						"handshake": map[string]any{"server": "127.0.0.1", "server_port": e.realityDest}, "private_key": e.realityPriv, "short_id": []string{"0123456789abcdef"}}}})
			},
			client: func(e *env, u user, port int) map[string]any {
				return map[string]any{"type": "vless", "tag": "out", "server": "127.0.0.1", "server_port": port, "uuid": u.UUID,
					"multiplex": map[string]any{"enabled": true, "protocol": "smux", "max_connections": 1, "min_streams": 64},
					"tls": map[string]any{"enabled": true, "server_name": "rt.test", "utls": map[string]any{"enabled": true, "fingerprint": "chrome"},
						"reality": map[string]any{"enabled": true, "public_key": e.realityPub, "short_id": "0123456789abcdef"}}}
			}},
		{Name: "hysteria2", Tag: "hy2", Type: "hysteria2", Port: 21003, QUIC: true,
			server: func(e *env, us []user, reuse bool) map[string]any {
				return merge(listen(21003, reuse), map[string]any{"type": "hysteria2", "tag": "hy2", "tls": e.inTLS("h3"),
					"users": mapUsers(us, func(u user) map[string]any { return map[string]any{"name": u.Name, "password": u.Pass} })})
			},
			client: func(e *env, u user, port int) map[string]any {
				return map[string]any{"type": "hysteria2", "tag": "out", "server": "127.0.0.1", "server_port": port, "password": u.Pass, "tls": outTLS("h3")}
			}},
		{Name: "tuic", Tag: "tuic", Type: "tuic", Port: 21004, QUIC: true,
			server: func(e *env, us []user, reuse bool) map[string]any {
				return merge(listen(21004, reuse), map[string]any{"type": "tuic", "tag": "tuic", "tls": e.inTLS("h3"), "congestion_control": "bbr",
					"users": mapUsers(us, func(u user) map[string]any { return map[string]any{"name": u.Name, "uuid": u.UUID, "password": u.Pass} })})
			},
			client: func(e *env, u user, port int) map[string]any {
				return map[string]any{"type": "tuic", "tag": "out", "server": "127.0.0.1", "server_port": port, "uuid": u.UUID, "password": u.Pass,
					"congestion_control": "bbr", "udp_relay_mode": "native", "tls": outTLS("h3")}
			}},
		{Name: "anytls", Tag: "anytls", Type: "anytls", Port: 21005,
			server: func(e *env, us []user, reuse bool) map[string]any {
				return merge(listen(21005, reuse), map[string]any{"type": "anytls", "tag": "anytls", "tls": e.inTLS(),
					"users": mapUsers(us, func(u user) map[string]any { return map[string]any{"name": u.Name, "password": u.Pass} })})
			},
			client: func(e *env, u user, port int) map[string]any {
				return map[string]any{"type": "anytls", "tag": "out", "server": "127.0.0.1", "server_port": port, "password": u.Pass, "tls": outTLS()}
			}},
		{Name: "ss2022", Tag: "ss", Type: "shadowsocks", Port: 21006,
			server: func(e *env, us []user, reuse bool) map[string]any {
				return merge(listen(21006, reuse), map[string]any{"type": "shadowsocks", "tag": "ss", "method": "2022-blake3-aes-128-gcm", "password": ssPSK,
					"users": mapUsers(us, func(u user) map[string]any { return map[string]any{"name": u.Name, "password": u.SSKey} })})
			},
			client: func(e *env, u user, port int) map[string]any {
				return map[string]any{"type": "shadowsocks", "tag": "out", "server": "127.0.0.1", "server_port": port, "method": "2022-blake3-aes-128-gcm",
					"password": ssPSK + ":" + u.SSKey}
			}},
	}
}

// ---- server (in-process, upstream sing-box as a library) ----

type server struct {
	ctx  context.Context
	box  *box.Box
	gate *Gate
}

func parseInbounds(ctx context.Context, t testing.TB, ins []map[string]any) []option.Inbound {
	raw, _ := json.Marshal(map[string]any{"inbounds": ins})
	o, err := sjson.UnmarshalExtendedContext[option.Options](ctx, raw)
	if err != nil {
		t.Fatal(err)
	}
	return o.Inbounds
}

func startServer(t testing.TB, e *env, ps []proto, users []user, reuse bool) *server {
	g := NewGate()
	outReg := include.OutboundRegistry()
	RegisterGateOutbound(outReg, g)
	ctx := box.Context(context.Background(), include.InboundRegistry(), outReg, include.EndpointRegistry(),
		include.DNSTransportRegistry(), include.ServiceRegistry(), include.CertificateProviderRegistry())
	var ins []map[string]any
	for _, p := range ps {
		ins = append(ins, p.server(e, users, reuse))
	}
	cfg := map[string]any{
		"log":       map[string]any{"level": os.Getenv("SB_LOG_LEVEL"), "disabled": os.Getenv("SB_LOG_LEVEL") == ""},
		"inbounds":  ins,
		"outbounds": []map[string]any{{"type": GateOutboundType, "tag": "gate"}},
		"route":     map[string]any{"final": "gate"},
	}
	raw, _ := json.Marshal(cfg)
	opts, err := sjson.UnmarshalExtendedContext[option.Options](ctx, raw)
	if err != nil {
		t.Fatal(err)
	}
	b, err := box.New(box.Options{Context: ctx, Options: opts})
	if err != nil {
		t.Fatal(err)
	}
	b.Router().AppendTracker(g)
	if err := b.Start(); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { b.Close() })
	for _, p := range ps {
		for _, u := range users {
			g.Allow(Key{p.Tag, u.Name})
		}
	}
	return &server{ctx: ctx, box: b, gate: g}
}

// replaceInbound: InboundManager.Create with an existing tag (public API;
// starts the new inbound, then closes the old one).
func (s *server) replaceInbound(t testing.TB, e *env, p proto, users []user) error {
	ib := parseInbounds(s.ctx, t, []map[string]any{p.server(e, users, true)})[0]
	return s.box.Inbound().Create(s.ctx, s.box.Router(), s.box.LogFactory().NewLogger("inbound/"+p.Tag), ib.Tag, ib.Type, ib.Options)
}

// ---- client: real sing-box binary as a subprocess with a socks inbound ----

var nextClientPort atomic.Int32

func init() { nextClientPort.Store(int32(24000 + os.Getpid()%500*20)) }

type client struct {
	socks *socks.Client
	port  int
	cmd   *exec.Cmd
}

func startClient(t testing.TB, e *env, p proto, u user) *client {
	port := int(nextClientPort.Add(1))
	cfg := map[string]any{
		"log":       map[string]any{"level": "warn"},
		"inbounds":  []map[string]any{{"type": "socks", "tag": "in", "listen": "127.0.0.1", "listen_port": port}},
		"outbounds": []map[string]any{p.client(e, u, p.Port)},
	}
	dir := t.TempDir()
	path := filepath.Join(dir, "c.json")
	raw, _ := json.MarshalIndent(cfg, "", " ")
	os.WriteFile(path, raw, 0o600)
	cmd := exec.Command(singboxBin, "run", "-c", path)
	logf, _ := os.Create(filepath.Join(os.Getenv("SPIKE_LOGDIR")+"/", fmt.Sprintf("client-%s-%s-%d.log", p.Name, u.Name, port)))
	if logf != nil {
		cmd.Stdout, cmd.Stderr = logf, logf
	}
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { cmd.Process.Kill(); cmd.Wait() })
	for i := 0; i < 100; i++ {
		c, err := net.Dial("tcp", fmt.Sprintf("127.0.0.1:%d", port))
		if err == nil {
			c.Close()
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	return &client{socks: socks.NewClient(N.SystemDialer, M.ParseSocksaddrHostPort("127.0.0.1", uint16(port)), socks.Version5, "", ""), port: port, cmd: cmd}
}

func (c *client) dial(port int) (net.Conn, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	return c.socks.DialContext(ctx, "tcp", M.ParseSocksaddrHostPort("127.0.0.1", uint16(port)))
}

func (c *client) udp(port int) (net.PacketConn, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	return c.socks.ListenPacket(ctx, M.ParseSocksaddrHostPort("127.0.0.1", uint16(port)))
}

// echo writes n bytes and reads them back within d.
func echo(c net.Conn, n int, d time.Duration) error {
	c.SetDeadline(time.Now().Add(d))
	defer c.SetDeadline(time.Time{})
	out := bytes.Repeat([]byte{'x'}, n)
	errc := make(chan error, 1)
	go func() { _, err := c.Write(out); errc <- err }()
	in := make([]byte, n)
	if _, err := io.ReadFull(c, in); err != nil {
		return err
	}
	return <-errc
}

func udpEcho(pc net.PacketConn, dst int, n, count int, d time.Duration) (int, error) {
	pc.SetDeadline(time.Now().Add(d))
	defer pc.SetDeadline(time.Time{})
	to := &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: dst}
	got := 0
	b := make([]byte, 65536)
	for i := 0; i < count; i++ {
		if _, err := pc.WriteTo(bytes.Repeat([]byte{'u'}, n), to); err != nil {
			return got, err
		}
		m, _, err := pc.ReadFrom(b)
		if err != nil {
			return got, err
		}
		got += m
	}
	return got, nil
}

// dead: an established conn is considered cut if a read returns an error
// (EOF/reset) within d — NOT a timeout.
func dead(c net.Conn, d time.Duration) bool {
	c.SetDeadline(time.Now().Add(d))
	_, _ = c.Write([]byte("ping"))
	b := make([]byte, 16)
	for {
		_, err := c.Read(b)
		if err != nil {
			var ne net.Error
			if ok := asNetErr(err, &ne); ok && ne.Timeout() {
				return false
			}
			return true
		}
	}
}

func asNetErr(err error, ne *net.Error) bool {
	v, ok := err.(net.Error)
	if ok {
		*ne = v
	}
	return ok
}
